import SettingsPage from './SettingsPage.vue'

export { SettingsPage }
