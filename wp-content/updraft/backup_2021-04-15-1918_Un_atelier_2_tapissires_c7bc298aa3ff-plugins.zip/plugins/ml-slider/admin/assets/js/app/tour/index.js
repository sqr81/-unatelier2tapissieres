import MainTour from './main'

// @codingStandardsIgnoreStart
// Also create a generic tour if needed (useful if we need a more detailled hint)
// const Tour = new window.Shepherd.Tour()
// Tour.options.defaults = {
// 	classes: 'shepherd-theme-arrows shepherd-metaslider-tour',
// 	showCancelLink: true
// }
// @codingStandardsIgnoreEnd

export { MainTour }
